# 🖥️ Backend – The Taste That Remains

This is the backend component of the **"The Taste That Remains"** web application — a memorial platform that honors the fallen of October 7th through their favorite recipes and personal stories.

The backend handles form submissions (recipes and contact forms), connects to a MySQL database, and allows further data processing (e.g., export to CSV, approval status, etc.).

---

## ⚙️ Local Setup Instructions

These steps explain how to fully set up the backend and connect it to the MySQL database.

---

### ✅ 1. Create and load the MySQL database

#### A. Open CMD and navigate to the MySQL bin directory:
```bash
cd "C:\Program Files\MySQL\MySQL Server 8.x\bin"  # Replace with your installed version
```

#### B. Login to MySQL:
```bash
mysql -u root -p
```
Enter your personal MySQL password when prompted.

#### C. Create the database:
```sql
CREATE DATABASE the_taste_that_remains_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```
Then type:
```sql
exit
```

#### D. Load the SQL file (replace with your path):
```bash
mysql -u root -p the_taste_that_remains_db < "C:/your/path/to/the_taste_that_remains.session.sql"
```

---

### 🛠️ 2. Configure MySQL credentials

Open the following file:
```
DatabaseIntegration/config/db.config.js
```
Update this section:
```js
module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "your_password_here",
  DB: "the_taste_that_remains_db"
};
```

---

### 📦 3. Install dependencies

In terminal, navigate to the backend folder:
```bash
cd project/DatabaseIntegration
```
Then install packages:
```bash
npm install
```
If nodemon is not installed globally:
```bash
npm install -g nodemon
```

---

### ▶️ 4. Start the server

From inside `DatabaseIntegration` folder, run:
```bash
nodemon server.js
```
You should see:
```
Server running on port 3000
Connected to MySQL!
```

---

## 🧪 SQL Utility Commands

### ✅ Approve a submitted recipe:
```sql
UPDATE recipes_requests
SET status = 'APPROVED'
WHERE id = X;
```

### ❌ Delete an uploaded recipe:
```sql
DELETE FROM uploaded_recipes
WHERE recipe_name = 'XXXX' AND fallen_name = 'XXXX'
ORDER BY approved_at DESC
LIMIT 1;
```

---

## 📂 SQL Schema Overview

The `.sql` file includes the database creation, table definitions, and initial data.

Tables used:
- `recipes_requests` — recipes submitted by users
- `uploaded_recipes` — approved recipes
- `contact_messages` — messages from contact form

---

## 👤 Authors

- **Daniella Hadas**
- **Eden Dafa**
- **Anog Shtorper**

---

## 📄 License

This backend is provided for educational and memorial purposes.
All submitted content is manually reviewed. No commercial use permitted.
