const mysql = require("mysql2");
const dbConfig = require("./db.config.js");

const connection = mysql.createConnection({
    host: dbConfig.HOST,
    user: dbConfig.USER,
    password: dbConfig.PASSWORD,
    database: dbConfig.DB,
    charset: 'utf8mb4'
});

connection.connect(error => {
    if (error) throw error;
    console.log("Connected to the database.");
});

module.exports = connection;


