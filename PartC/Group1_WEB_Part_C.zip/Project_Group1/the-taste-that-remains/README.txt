# 🌟 The Taste That Remains — הטעם שנשאר

> A memorial website honoring the fallen of October 7th through their favorite recipes and personal stories.

[🌐 Live Version on GitHub Pages](https://hadasdaniella.github.io/WEBProject/)

---

## 🕯️ Project Purpose

**"The Taste That Remains"** is a heartfelt digital initiative combining memory and cuisine.  
Each recipe on the site is linked to a fallen individual and accompanied by a short story in their memory.  
Through food and storytelling, we aim to preserve legacy, share emotion, and build community.

---

## 🧭 Features

- 🏠 **Home Page** – Displays memorial recipe cards with images, names, and short descriptions.
- ➕ **Add Recipe Page** – Allows visitors to submit new recipes in memory of loved ones.
- 💬 **Contact Page** – Structured form to reach the team behind the project.
- 📱 **Responsive Design** – Works seamlessly across mobile, tablet, and desktop.

---

## 🛠️ Tech Stack

- **HTML5** – Semantic and accessible markup
- **CSS3** – Custom styling with responsiveness via media queries
- **JavaScript (main.js)** – Client-side logic (planned interactivity & enhancements)
- **Google Fonts** – Fredoka & Secular One typography
- **[Planned] Backend:** Node.js + Express + MongoDB (see server README)

---

## 📁 Project Structure

- home.html
- add-recipe.html
- contact.html
- recipe.html (planned)
- style.css
- images/ (folder containing all images)
- favicon.ico (url icon)


## 🙋‍♀️ Team

Developed by:

- **Daniella Hadas**  
- **Eden Dafa**  
- **Anog Shtorper**

> Created as a personal memorial initiative, combining culture, emotion, and web development.

---

## 📄 License

This is a personal, non-commercial project.  
All stories, names, and photos have been added with awareness and consent.  
No content may be reused without explicit permission.

