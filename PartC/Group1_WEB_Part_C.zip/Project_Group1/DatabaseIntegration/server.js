// ============================
//     Module Imports
// ============================
const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const dbConfig = require('./db.config.js');
const multer = require('multer');

// ============================
//     Express App Setup
// ============================
const app = express();
const PORT = 3000;

// ============================
//     Middleware
// ============================
// Serve all static files (HTML, CSS, JS, images) from the main folder
app.use(express.static(path.join(__dirname, '..', 'the-taste-that-remains')));
// Serve images via /images path
app.use('/images', express.static(path.join(__dirname, '..', 'the-taste-that-remains', 'images')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json()); 

// ============================
//     Multer Storage Setup (Safe Unique Names)
// ============================
// Configure multer for handling file uploads (images):
// - Destination is the 'images' folder inside 'the-taste-that-remains'.
// - Filename will be unique: a timestamp + random number + fieldname + original extension.
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dest = path.join(__dirname, '..', 'the-taste-that-remains', 'images');
        cb(null, dest);
    },
    filename: (req, file, cb) => {
        let ext = path.extname(file.originalname).toLowerCase() || '.jpg';
        const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, unique + '-' + file.fieldname + ext);
    }
});
const upload = multer({ storage });

// ============================
//     MySQL Database Setup
// ============================
// Setup the connection to MySQL using configuration file
const connection = mysql.createConnection({
    host: dbConfig.HOST,
    user: dbConfig.USER,
    password: dbConfig.PASSWORD,
    database: dbConfig.DB,
    charset: 'utf8mb4'
    
});
connection.connect(err => {
    if (err) {
        console.error('Failed to connect to MySQL:', err);
        process.exit(1);
    }
    console.log("Connected to MySQL!");
});

// ============================
//     Helper: Ensure Always Array
// ============================
// Ensures that a value is always returned as an array.
// This helps handle single or multiple input fields (e.g. ingredients).
function toArray(val) {
    if (val === undefined) return [];
    return Array.isArray(val) ? val : [val];
}

// ============================
//     Routes
// ============================

/**
 * Root route – serves the main homepage (index.html)
 */
app.get(['/', '/home', '/home.html'], (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'the-taste-that-remains', 'index.html'));
});

// Add Recipe page
app.get(['/add-recipe', '/add-recipe.html'], (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'the-taste-that-remains', 'add-recipe.html'));
});

// Contact page
app.get(['/contact', '/contact.html'], (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'the-taste-that-remains', 'contact.html'));
});

// Recipe (individual recipe or list)
app.get(['/recipe', '/recipe.html'], (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'the-taste-that-remains', 'recipe.html'));
});


/**
 * Get the latest 8 approved recipes for the homepage grid.
 * Responds with an array of recipe objects (for the grid on the homepage).
 * Data is fetched from the 'uploaded_recipes' table and ordered by approval time.
 */
app.get('/api/recipes/latest', (req, res) => {
    const sql = `
      SELECT recipe_name, fallen_name, category, dish_photo_url, fallen_photo_url
      FROM uploaded_recipes
      ORDER BY approved_at DESC
      LIMIT 8
    `;
    connection.query(sql, (err, results) => {
        if (err) {
            console.error("DB Error (latest recipes):", err);
            return res.status(500).json({ success: false, message: "Database error" });
        }
        res.json(results);
    });
});

/**
 * Contact Form Submission.
 * Handles contact form submissions from the website.
 * - Expects fields: name, email, message.
 * - If missing fields, responds with 400.
 * - Otherwise, saves to 'contact_messages' table in MySQL.
 * - Responds with JSON { success: true } on success.
 * 
 * NOTE: Only this route uses urlencoded parser, as it's a simple text form.
 */
app.post('/submit-contact', upload.none(), async (req, res) => {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
        return res.status(400).json({ success: false, message: "Missing required fields" });
    }
    const sql = `
        INSERT INTO contact_messages (name, email, message)
        VALUES (?, ?, ?)
    `;
    connection.query(sql, [name, email, message], (err) => {
        if (err) {
            console.error("DB Error (contact):", err);
            return res.status(500).json({ success: false, message: "Database error" });
        }
        res.status(200).json({ success: true, message: "Message sent successfully!" });
    });
});

/**
 * Recipe Submission Route.
 * Handles full recipe form submissions (with image upload).
 * - Receives all recipe data and files (images) from a multipart/form-data request.
 * - Multer parses files; body fields are in req.body, images in req.files.
 * - Handles multiple or single ingredient/quantity fields safely.
 * - Validates that all required fields exist.
 * - Saves image file paths and recipe data to the 'recipes_requests' table in MySQL.
 * - Responds with { success: true } if saved, or { success: false } with 400/500 on error.
 */
app.post('/submit-recipe', upload.fields([
    { name: 'dish-photo', maxCount: 1 },
    { name: 'fallen-photo', maxCount: 1 }
]), (req, res) => {
    // DEBUG: print the received body and files for troubleshooting
    console.log('BODY:', req.body);
    console.log('FILES:', req.files);

    // Destructure expected form fields from body
    const {
        'full-name': author_name,
        email: author_email,
        phone,
        'recipe-name': recipe_name,
        'fallen-name': fallen_name,
        dob,
        dod,
        hometown,
        'personal-story': personal_story,
        preparation,
        category
    } = req.body;

    // Gather and combine ingredient and quantity fields (handle both array and single)
    const ingredientsArr = toArray(req.body['ingredient[]'] || req.body['ingredient']);
    const quantitiesArr = toArray(req.body['quantity[]'] || req.body['quantity']);
    const ingredients = ingredientsArr.map((ing, i) =>
        (quantitiesArr[i] ? `${quantitiesArr[i]} ${ing}` : ing)
    ).join(', ');

    // Prepare image URLs (only if files uploaded)
    let dish_photo_url = '';
    let fallen_photo_url = '';
    if (req.files && req.files['dish-photo'] && req.files['dish-photo'][0]) {
        dish_photo_url = 'images/' + req.files['dish-photo'][0].filename;
    }
    if (req.files && req.files['fallen-photo'] && req.files['fallen-photo'][0]) {
        fallen_photo_url = 'images/' + req.files['fallen-photo'][0].filename;
    }

    // Validate required fields – if any missing, respond 400 Bad Request
    if (
        !author_name ||
        !author_email ||
        !phone ||
        !recipe_name ||
        !fallen_name ||
        !dob ||
        !dod ||
        ingredientsArr.length === 0 ||
        !preparation ||
        !category
    ) {
        return res.status(400).json({ success: false, message: "Missing required fields" });
    }

    // Prepare SQL query and parameters for inserting the new recipe submission
    const sql = `
        INSERT INTO recipes_requests
        (recipe_name, author_name, author_email, phone, fallen_name, dob, dod, hometown, personal_story, ingredients, preparation, category, fallen_photo_url, dish_photo_url)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
        recipe_name,
        author_name,
        author_email,
        phone,
        fallen_name,
        dob,
        dod,
        hometown || '',
        personal_story || '',
        ingredients,
        preparation,
        category,
        fallen_photo_url,
        dish_photo_url
    ];

    // Log parameters for debugging
    console.log("PARAMS:", params);

    // Execute the query: insert recipe request into MySQL
    connection.query(sql, params, (err) => {
        if (err) {
            console.error("DB Error (recipe):", err);
            return res.status(500).json({ success: false, message: "Database error" });
        }
        res.status(200).json({ success: true, message: "Recipe submitted successfully!" });
    });
});

// ============================
//     Start the Server
// ============================
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
