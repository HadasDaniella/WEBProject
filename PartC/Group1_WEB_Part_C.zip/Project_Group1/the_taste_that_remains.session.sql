                    -- the following queries are initial to start the database 

-- Create database and use it
CREATE DATABASE IF NOT EXISTS the_taste_that_remains_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;
USE the_taste_that_remains_db;

-- Create recipes_requests table
CREATE TABLE IF NOT EXISTS recipes_requests (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    recipe_name VARCHAR(255) NOT NULL,
    author_name VARCHAR(255) NOT NULL,
    author_email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    fallen_name VARCHAR(255) NOT NULL,
    dob DATE,
    dod DATE,
    hometown VARCHAR(255),
    personal_story TEXT,
    ingredients TEXT NOT NULL,
    preparation TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    fallen_photo_url VARCHAR(255),
    dish_photo_url VARCHAR(255),
    request_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('PENDING', 'APPROVED', 'DENIED') NOT NULL DEFAULT 'PENDING'
);

-- Create contact_messages table
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create uploaded_recipes table
CREATE TABLE IF NOT EXISTS uploaded_recipes (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    recipe_name VARCHAR(255) NOT NULL,
    fallen_name VARCHAR(255) NOT NULL,
    dob DATE,
    dod DATE,
    hometown VARCHAR(255),
    personal_story TEXT,
    ingredients TEXT NOT NULL,
    preparation TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    fallen_photo_url VARCHAR(255),
    dish_photo_url VARCHAR(255),
    approved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create the trigger for approval
DELIMITER //

CREATE TRIGGER IF NOT EXISTS moveApprovedRecipe
AFTER UPDATE ON recipes_requests
FOR EACH ROW
BEGIN
    IF OLD.status <> 'APPROVED' AND NEW.status = 'APPROVED' THEN
        INSERT INTO uploaded_recipes (
            recipe_name,
            fallen_name,
            dob,
            dod,
            hometown,
            personal_story,
            ingredients,
            preparation,
            category,
            fallen_photo_url,
            dish_photo_url
        )
        VALUES (
            NEW.recipe_name,
            NEW.fallen_name,
            NEW.dob,
            NEW.dod,
            NEW.hometown,
            NEW.personal_story,
            NEW.ingredients,
            NEW.preparation,
            NEW.category,
            NEW.fallen_photo_url,
            NEW.dish_photo_url
        );
    END IF;
END//

DELIMITER ;

-- Insert 8 initial recipes
INSERT INTO uploaded_recipes
(recipe_name, fallen_name, dob, dod, hometown, personal_story, ingredients, preparation, category, fallen_photo_url, dish_photo_url)
VALUES
('קציצות מחשי וקוסקוס', 'קארין ג׳ורנו ז״ל', '1990-01-01', '2023-10-07', 'תל אביב', 'קארין אהבה לבשל למשפחה...', 'קילו בשר טחון, 2 בצלים, חופן אורז', 'ללוש הכל, למלא ירקות, לבשל ברוטב עגבניות', 'בשרי', 'images/karin-jorno.jpg', 'images/mahshi.jpg'),
('עוגיות שוקולד צ׳יפס', 'דקל סויסה ז״ל', '1992-03-12', '2023-10-07', 'באר שבע', 'דקל היה חובב מתוקים...', '2 כוסות קמח, 1/2 כוס חמאה, שוקולד צ׳יפס', 'לערבב, ליצור עיגולים, לאפות 12 דק׳', 'קינוח', 'images/DekelSuissa.png', 'images/cookies.jpg'),
('עוגת גזר', 'מאיה פודר ז״ל', '1988-06-05', '2023-10-07', 'חיפה', 'מאיה נהגה לאפות עם אימה כל שבת', '3 גזרים מגורדים, 2 ביצים, 1 כוס קמח', 'לערבב, לאפות 40 דק׳', 'קינוח', 'images/MayaFuder.png', 'images/carrot-cake.jpeg'),
('עוגת גבינה עם פירות', 'אליהו מאיר אוחנה ז״ל', '1986-11-22', '2023-10-07', 'נתניה', 'המתכון עבר במשפחה מדור לדור', '250 גר׳ גבינה, 3 ביצים, פירות העונה', 'להקציף, לשפוך לתבנית, להניח פירות, לאפות', 'קינוח', 'images/EliyahuMeirOhana.png', 'images/cheescake.jpeg'),
('עילת של אחסן', 'אחסן דקסה ז״ל', '1995-04-15', '2023-10-07', 'דימונה', 'מאכל פרווה משפחתי מיוחד', '2 כוסות קמח, כוס מים, שמן', 'לערבב, ליצור עיגולים, לטגן', 'פרווה', 'images/AhsanDaksa.jpeg', 'images/ahsan-dish.jpeg'),
('כריך רוני', 'רוני אשל ז״ל', '1991-09-20', '2023-10-07', 'הרצליה', 'כריך של רוני היה ידוע בין החברים', 'לחמנייה, גבינה צהובה, חסה, עגבנייה', 'לחתוך, להרכיב ולסגור', 'חלבי', 'images/RoniEshel.jpeg', 'images/sandwich.jpeg'),
('פאי לימון', 'אייל מבורך טויטו ז״ל', '1993-02-02', '2023-10-07', 'אשקלון', 'פאי הלימון של אייל בימי שישי', '1 בסיס בצק, קרם לימון, מרנג', 'לאפות את הבסיס, למלא בקרם, להוסיף מרנג', 'קינוח', 'images/EyalMeborachTuito.png', 'images/lemon-pie.jpeg'),
('פיצה איטלקית', 'איתי גליסקו ז״ל', '1990-08-11', '2023-10-07', 'תל אביב', 'פיצה איטלקית אמיתית של איתי', '1 בצק שמרים, רוטב עגבניות, גבינת מוצרלה', 'לרדד, להוסיף רוטב וגבינה, לאפות 10 דק׳', 'חלבי', 'images/ItayGlisko.jpeg', 'images/pizza.jpeg');


                            -- from here you can write queries as you wish


SHOW DATABASES;

SELECT * FROM uploaded_recipes;
SELECT * FROM recipes_requests;
SELECT * FROM contact_messages;
